import css from './style.scss'

const page = `
    <h1 class="Main-title">Hola Mundo con Vanilla JS, Webpack, & Sass</h1>
`

document.getElementById('root').innerHTML = page
